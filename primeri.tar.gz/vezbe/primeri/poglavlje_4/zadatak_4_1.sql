-- Otkomentarisati narednu liniju i zakomentarisati liniju ispod nje kako bi se prikazala detaljna greska u programu.
-- UPDATE   PREDMET
UPDATE  DA.PREDMET
SET     ESPB = ESPB + 1;
