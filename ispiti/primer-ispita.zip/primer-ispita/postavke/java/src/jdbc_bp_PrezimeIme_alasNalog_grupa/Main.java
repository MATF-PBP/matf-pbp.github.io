package jdbc_bp_PrezimeIme_alasNalog_grupa;

import java.sql.*;
import java.util.Scanner;

public class Main {
	
	static {
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public static void main(String[] args) {
		String url = "jdbc:db2://localhost:50000/STUD2020";

		try (
			Connection con = DriverManager.getConnection(url, "student", "abcdef");
			Scanner ulaz = new Scanner(System.in);
		) {
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(2);
		}
	}

	private static void aPronadjiSveKandidate(Connection con) throws SQLException {
		
	}
	
	private static void bUnesiPoeneSaTesta(Connection con, Scanner ulaz) throws SQLException {
		
	}

	private static void cUnesiPoeneNaTestuZaStudenta(Connection con, Integer indeks, Scanner ulaz) throws SQLException {
		
	}
}
