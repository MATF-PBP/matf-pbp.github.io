package hibernate_bp_PrezimeIme_alasNalog_grupa;

public class Main {
	
	public static void main(String[] args) {
		
	}
	
}
