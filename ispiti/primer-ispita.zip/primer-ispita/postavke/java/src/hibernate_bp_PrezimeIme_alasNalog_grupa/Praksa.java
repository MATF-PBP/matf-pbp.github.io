package hibernate_bp_PrezimeIme_alasNalog_grupa;

public class Praksa {
	
}
